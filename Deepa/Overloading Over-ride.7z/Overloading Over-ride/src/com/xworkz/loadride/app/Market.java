package com.xworkz.loadride.app;

public class Market {

	public void buy()
	{
		System.out.println("invocking no args in Market");
	}
	public void buy(int Buyers,int noStalls) 
	{
		
	}
	public void buy(int Buyers,int noStalls,String location)
	{
		
	}
	public void buy(int Buyers,int noStalls,String location,boolean open)
	{
		
	}
	public void buy(int Buyers,int noStalls,String location,boolean open, long product)
	{
		
	}
	public void buy(int Buyers,int noStalls,String location,boolean open, long product,int hours)
	{
		
	}
}

// is use to control the access of the class from another class