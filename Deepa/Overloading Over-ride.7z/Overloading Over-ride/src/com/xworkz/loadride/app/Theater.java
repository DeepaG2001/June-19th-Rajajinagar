package com.xworkz.loadride.app;

public class Theater {

	public String name;
	public double price;
	public int noOfSeat;
	public String location;
	public boolean hasBalcony;
	public  String movieName;
	
	public void watch() 
	{
		System.out.println("invocking no-args in Theater");
	}
	public void watch( String name,double price)
	{
		
	}
	public void watch( String name,double price, int noOfSeat)
	{
		
	}
	public void watch( String name,double price, int noOfSeat, String location)
	{
		
	}
	public void watch( String name,double price, int noOfSeat, String location, boolean hasBalcony)
	{
		
	}
	public void watch( String name,double price, int noOfSeat, String location, boolean hasBalcony,  String movieName)
	{
		
	}
}
