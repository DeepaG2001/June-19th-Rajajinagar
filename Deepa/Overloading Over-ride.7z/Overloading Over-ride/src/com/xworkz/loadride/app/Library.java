package com.xworkz.loadride.app;

public class Library {

	public String name;
	public int noOfStaff;
	public int noOfBooks;
	public boolean isOpen;
	public double lateFee;
	public String website;

	public void read() {
		System.out.println("invocking no-args in Library");
	}

	public void read(String name, int noOfStaff) {
		
	}

	public void read(String name, int noOfStaff, int noOfBooks) {
	}

	public void read(String name, int noOfStaff, int noOfBooks, boolean isOpen) {
	}

	public void read(String name, int noOfStaff, int noOfBooks, boolean isOpen, double lateFee) {
		
	}

	public void read(String name, int noOfStaff, int noOfBooks, boolean isOpen, double lateFee, String website) {
	}
}
