package com.xworkz.loadride.app;

public class Temple {

	public void pray() {
		System.out.println("invocking no=args in Temple");
	}

	public void pray(String name, boolean isOpen) {

	}

	public void pray(String name, boolean isOpen, double donation) {

	}

	public void pray(String name, boolean isOpen, double donation, String location) {

	}

	public void pray(String name, boolean isOpen, double donation, String location, int capacity) {

	}

	public void pray(String name, boolean isOpen, double donation, String location, int capacity, int priestCount) {

	}

}
