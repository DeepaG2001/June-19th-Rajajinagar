package com.xworkz.loadride.app;

public class Hotel {

	public int rating;
	public String location;
	public boolean guestRoom;
	public boolean parking;
	public int security;
	public boolean swimming;
	
	
	public void business()
	{
		System.out.println("invocking no-args in hotel");
	}
	public void business(int rating,String location)
	{
		
	}
	public void business( int rating, String location, boolean guestRoom)
	{
	}
	public void business( int rating, String location, boolean guestRoom, boolean parking)
	{
	}
	public void business( int rating, String location, boolean guestRoom, boolean parking, int security)
	{
	}
	public void business( int rating, String location, boolean guestRoom, boolean parking, int security, boolean swimming)
	{
	}
}
