package com.xworkz.loadride.app;

public class Hostel {

	public int floor;
	public boolean hasWiFi;
	public String address;
	public double distance;
	public boolean hasLaundry;
	public int totalRooms;
	
	public void stay()
	{
		System.out.println("invocking no-args in Hostel");
	}
	public void stay( int floor, boolean hasWiFi)
	{
		
	}
	public void stay( int floor, boolean hasWiFi, String address)
	{
		
	}
	public void stay( int floor, boolean hasWiFi, String address, double distance)
	{
		
	}
	public void stay( int floor, boolean hasWiFi, String address, double distance, boolean hasLaundry)
	{
		
	}
	
	public void stay( int floor, boolean hasWiFi, String address, double distance, boolean hasLaundry, int totalRooms)
	{
		
	}
}
