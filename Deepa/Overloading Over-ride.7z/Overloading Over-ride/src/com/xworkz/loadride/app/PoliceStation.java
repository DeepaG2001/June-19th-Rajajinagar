package com.xworkz.loadride.app;

public class PoliceStation {

	public void protect()
	{
		System.out.println("invocking no args in PoliceStation");
	}
	
	public void protect(String name ,String location) 
	{
		
	}
	public void protect(String name ,String location,int noOfOfficers) 
	{
		
	}
	public void protect(String name ,String location,int noOfOfficers,boolean isEmergency) 
	{
		
	}
	public void protect(String name ,String location,int noOfOfficers,boolean isEmergency,long noOfCriminals) 
	{
		
	}
	public void protect(String name ,String location,int noOfOfficers,boolean isEmergency,long noOfCriminals,long hours) 
	{
		
	}
}
