package com.xworkz.loadride.app;

public class Mall {
	
	 public void shop() {
		 System.out.println("invocking no-args in Mall");
	 }
	 public void shop(String name,String location)
	 {
		 
	 }
	 public void shop(String name,String location,int noOfFloors)
	 {
		 
	 }
	 public void shop(String name,String location,int noOfFloors,boolean hasParking)
	 {
		 
	 }
	 public void shop(String name,String location,int noOfFloors,boolean hasParking,boolean hasMovieTheater)
	 {
		 
	 }
	 public void shop(String name,String location,int noOfFloors,boolean hasParking,boolean hasMovieTheater,int noOfEscalators)
		{
			
		}	
}
