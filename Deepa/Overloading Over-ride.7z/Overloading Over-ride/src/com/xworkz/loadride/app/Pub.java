package com.xworkz.loadride.app;

public class Pub {

	public void enjoy()
	{
		System.out.println("invocking no arg in pub");
	}
	public void enjoy(int noOfTables,String name)
	{
		
	}
	public void enjoy(int noOfTables,String name, String location)
	{
		
	}
	public void enjoy(int noOfTables,String name, String location,boolean isOpen)
	{
		
	}
	public void enjoy(int noOfTables,String name, String location,boolean isOpen,boolean entertainment)
	{
		
	}
	public void enjoy(int noOfTables,String name, String location,boolean isOpen,boolean entertainment,double price)
	{
		
	}
}
