package com.xworkz.loadride.app;

public class Zoo {

	public void prison() {
		System.out.println("invocking no-args in Zoo");
	}
	
	public void prison(double price,String name)
	{
		
	}
	public void prison(double price,String name,String location)
	{
		
	}
	public void prison(double price,String name,String location,long noOfVisitors)
	{
		
	}
	public void prison(double price,String name,String location,long noOfVisitors, int noAnimal)
	{
		
	}
	public void prison(double price,String name,String location,long noOfVisitors, int noAnimal,boolean splEvent)
	{
		
	}
}
