package com.xworkz.loadride.app;

public class City {

	public void place()
	{
		System.out.println("invocking no-args in City");
	}
	public void place(String name,long population)
	{
		
	}
	public void place(String name,long population,long foundedYear)
	{
		
	}
	public void place(String name,long population,long foundedYear,boolean transportation)
	{
		
	}
	public void place(String name,long population,long foundedYear,boolean transportation,double temprature)
	{
		
	}
	public void place(String name,long population,long foundedYear,boolean transportation,double temprature,boolean isIndustryArea)
	{
		
	}
}
