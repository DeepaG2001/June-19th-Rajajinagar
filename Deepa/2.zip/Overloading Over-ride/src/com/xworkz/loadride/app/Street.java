package com.xworkz.loadride.app;

public class Street {

	public void road()
	{
		System.out.println("invocking no-args in Street");
	}
	public void road(String name,int length) 
	{
		
	}
	public void road(String name,int length, int noOfHOuse) 
	{
		
	}
	public void road(String name,int length, int noOfHOuse,boolean sideWalk) 
	{
		
	}
	public void road(String name,int length, int noOfHOuse,boolean sideWalk,int noOfPeople) 
	{
		
	}
	public void road(String name,int length, int noOfHOuse,boolean sideWalk,int noOfPeople, boolean lessTraffic) 
	{
		
	}
}
